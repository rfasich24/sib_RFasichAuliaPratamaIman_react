let variable = "Variable adalah deklarasi untuk menyimpan suatu nilai, jika diumpamakan variable adalah kotak kosong yang nantinya dapat diisi dengan barang";
// alert(variable);
console.log(variable);

let pentingVariable = "Pentingnya variable adalah sebagai wadah untuk menyimpan suatu nilai agar nantinya variable ini dapat digunakan kembali pada kondisi tertentu" ;
// alert(pentingVariable);
console.log(pentingVariable);

let deklarasiVariable = "Untuk mendeklarasikan variable kita bisa menggunakan salah satu dari let, cons, var tergantung kondisi";
let nama;
let alamat;
let umur;
// alert(deklarasiVariable);
console.log(deklarasiVariable);

let isiVariable = "Mengisi variable dengan nilai/value";
nama = "fasich";
alamat = "jember";
umur = "20"
// alert(isiVariable);
console.log(isiVariable);
let _fa = "sjjjs";
let namaVariable = "Pemberian nama variable yang baik adalah variable tidak diawali dengan angka, tidak menggunakan nama yang sudah dikontrak oleh bahasa js seperti for, while dll, diawal dan diakhir kata bisa menggunakan simbol";
let namaLengkap = "R. Fasich Aulia Pratama Iman";
let alamat_rumah = "Jl. Sumatra Jember";
let _umurSekarang = "20";
// alert(namaVariable);
console.log(namaVariable);

let tipeData = "Tipe data adalah sebuah penglompokan data kedalam tipe2 tertentu";
let jenisTipeData = "Jenis tipe data diantaranya string, number, boolean";
let tipeDataNumber = "Untuk membuat tipe data number kita dapat langsung mengisikan value angka pada isi variable";
let iniAngka = 25;
// alert(tipeData);
console.log(tipeData);

let tipeDataString = "Untuk membuat tipe data string kita bisa menulisakan sebuah kalimat/kata/apapun itu dengan diapit oleh tanda petik";
let iniString = "Ini adalah sebuah variable dengan tipe data string";
// alert(tipeDataString);
console.log(tipeDataString);

let tipeDataBoolean = "Tipe data boolean adalah tipe data kondisi, umumnya tipe data ini berisi nilai true atau false";
let iniBool = true;
// alert(tipeDataBoolean);
console.log(tipeDataBoolean);

let cekTipeData = "Cara mengecek tipe data adalah menggunakan typeof";
typeof "ini tulisan"
// alert(cekTipeData);
console.log(cekTipeData);

let apaItuArray = "Array adalah sebuah variable yang dapat menyimpan banyak data sekaligus baik itu denan tipe yang sama maupun berbeda";
// alert(apaItuArray);
console.log(apaItuArray);

let jenisArray = "Jenis array ada single dimensi dan multi dimensi. Single dimensi adalah array dengan 1 dimansi sedangkan multi dimensi adalah array yang memiliki array juga didalamnya";
let singleDimension = ["buku", "baju", "celana"];
let multidimension = [["buku", "baju"], ["buku", "celana"], ["baju", "celana"]]
// alert(jenisArray);
console.log(jenisArray);

let isiArray = "Mengisi sebuah array"
let buku = ["fiksi", "romantis", "thriller", "comic"]
// alert(isiArray);
console.log(isiArray + buku);

